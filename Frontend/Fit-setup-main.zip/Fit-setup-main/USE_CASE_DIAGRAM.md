# Use Case Diagram - Fit-setup Platform

## Document Information
- **Project Name**: Fit-setup
- **Document Type**: Use Case Diagram Documentation
- **Version**: 1.0
- **Last Updated**: October 27, 2025
- **Description**: E-commerce platform for fitness equipment with blog and user management features

---

## Table of Contents
1. [System Overview](#system-overview)
2. [Actors](#actors)
3. [Use Cases by Functional Area](#use-cases-by-functional-area)
4. [Detailed Use Case Descriptions](#detailed-use-case-descriptions)
5. [Use Case Relationships](#use-case-relationships)
6. [Visual Representation](#visual-representation)

---

## System Overview

**Fit-setup** is a fitness equipment e-commerce platform that allows users to browse products, read fitness blogs, manage their accounts, and purchase fitness equipment. The system supports both guest and registered users with varying levels of access.

### System Boundary
The Fit-setup system includes:
- User authentication and authorization
- Product browsing and shopping cart
- Blog content management
- User profile and account management
- Order processing and tracking

---

## Actors

### 1. Guest User (Primary Actor)
**Description**: Anonymous visitor to the website
**Access Level**: Limited, public-facing features only
**Capabilities**:
- Browse products and categories
- View blog articles
- View testimonials and brand partners
- Access login/registration pages

### 2. Registered Customer (Primary Actor)
**Description**: Authenticated user with an account
**Access Level**: Full access to customer features
**Capabilities**: All Guest User capabilities plus:
- Manage personal account details
- View and update profile information
- Manage shipping addresses
- Track order history
- Manage wishlist/favorites
- Track workout plans
- Add items to cart and checkout

### 3. Backend API Server (Secondary Actor)
**Description**: System component handling business logic
**Responsibilities**:
- Authenticate users (JWT-based)
- Validate user credentials
- Manage user data in database
- Process API requests
- Enforce security and authorization

### 4. MongoDB Database (Secondary Actor)
**Description**: Data persistence layer
**Responsibilities**:
- Store user accounts
- Store product information
- Store order history
- Store blog content

---

## Use Cases by Functional Area

### A. Authentication & User Management

| Use Case ID | Use Case Name | Primary Actor | Description |
|-------------|---------------|---------------|-------------|
| UC-001 | Register Account | Guest User | Create new user account with email and password |
| UC-002 | Login to Account | Guest User / Registered Customer | Authenticate with email and password |
| UC-003 | Logout from Account | Registered Customer | End authenticated session |
| UC-004 | View Profile | Registered Customer | Access user dashboard and account information |
| UC-005 | Update Account Details | Registered Customer | Modify name, phone, and personal information |
| UC-006 | Change Password | Registered Customer | Update account password with validation |

### B. Product Browsing & Shopping

| Use Case ID | Use Case Name | Primary Actor | Description |
|-------------|---------------|---------------|-------------|
| UC-007 | Browse Homepage | Guest User / Registered Customer | View landing page with featured products |
| UC-008 | Browse Product Categories | Guest User / Registered Customer | Filter products by category (Strength, Cardio, Functional) |
| UC-009 | View Product Details | Guest User / Registered Customer | See detailed product information |
| UC-010 | Add to Cart | Registered Customer | Add products to shopping cart |
| UC-011 | View Shopping Cart | Registered Customer | Review items in cart |
| UC-012 | Checkout | Registered Customer | Process order and payment |

### C. Content & Blog

| Use Case ID | Use Case Name | Primary Actor | Description |
|-------------|---------------|---------------|-------------|
| UC-013 | Browse Blog Articles | Guest User / Registered Customer | View paginated list of fitness articles |
| UC-014 | Filter Blog by Category | Guest User / Registered Customer | Browse articles by fitness topic |
| UC-015 | Read Blog Article | Guest User / Registered Customer | View full article content |
| UC-016 | View Testimonials | Guest User / Registered Customer | Read customer reviews |

### D. Order & Account Management

| Use Case ID | Use Case Name | Primary Actor | Description |
|-------------|---------------|---------------|-------------|
| UC-017 | View Order History | Registered Customer | Review past orders with status |
| UC-018 | Track Order Status | Registered Customer | Monitor delivery status |
| UC-019 | Manage Shipping Addresses | Registered Customer | Add, edit, or delete addresses |
| UC-020 | Manage Wishlist | Registered Customer | Add or remove favorite products |
| UC-021 | Manage Workout Plans | Registered Customer | Track fitness plans and exercises |

---

## Detailed Use Case Descriptions

### UC-001: Register Account

**Primary Actor**: Guest User
**Goal**: Create a new user account
**Preconditions**: User is not logged in
**Postconditions**: User account created, JWT token issued, user logged in

**Main Success Scenario**:
1. User navigates to login page
2. User selects "Register" tab
3. User enters email address
4. User enters password
5. System validates email format
6. System validates password strength (min 8 chars, uppercase, lowercase, numbers, special chars)
7. System checks email uniqueness
8. System hashes password with bcrypt
9. System creates user record in MongoDB
10. System generates JWT token (30-day expiration)
11. System returns user data and token
12. Client stores token in localStorage
13. User redirected to homepage as authenticated

**Alternative Flows**:
- 7a. Email already exists → Display error "Email already registered"
- 6a. Password too weak → Display validation errors with requirements

**Technical Details**:
- API Endpoint: `POST /api/auth/register`
- Request Body: `{email: string, password: string}`
- Response: `{_id: string, email: string, token: string}`

---

### UC-002: Login to Account

**Primary Actor**: Guest User / Registered Customer
**Goal**: Authenticate and access protected features
**Preconditions**: User has registered account
**Postconditions**: User authenticated, JWT token issued

**Main Success Scenario**:
1. User navigates to login page
2. User selects "Sign In" tab
3. User enters email address
4. User enters password
5. System finds user by email
6. System compares password with bcrypt hash
7. System generates JWT token
8. System returns user data and token
9. Client stores token in localStorage
10. User redirected to homepage as authenticated

**Alternative Flows**:
- 5a. Email not found → Display error "Invalid credentials"
- 6a. Password incorrect → Display error "Invalid credentials"

**Technical Details**:
- API Endpoint: `POST /api/auth/login`
- Request Body: `{email: string, password: string}`
- Response: `{_id: string, email: string, token: string}`

---

### UC-003: Logout from Account

**Primary Actor**: Registered Customer
**Goal**: End authenticated session
**Preconditions**: User is logged in
**Postconditions**: User session ended, token removed

**Main Success Scenario**:
1. User clicks profile dropdown in header
2. User selects "Sign Out" option
3. System removes JWT token from localStorage
4. System removes user email from localStorage
5. User redirected to homepage
6. Header displays "Sign In" link

**Alternative Flows**: None

---

### UC-004: View Profile

**Primary Actor**: Registered Customer
**Goal**: Access user dashboard and account information
**Preconditions**: User is logged in
**Postconditions**: User profile page displayed

**Main Success Scenario**:
1. User clicks profile dropdown in header
2. User selects "Account Information" or navigates to /profile
3. System checks JWT token validity
4. System retrieves user data from MongoDB
5. System displays profile page with tabs:
   - Account Details (name, phone)
   - Password Management
   - Shipping Address
   - Order History
   - Wishlist
   - Workout Plans

**Alternative Flows**:
- 3a. Token invalid/expired → Redirect to login page

**Technical Details**:
- API Endpoint: `GET /api/users/profile`
- Headers: `Authorization: Bearer <token>`
- Response: User object (password excluded)
- Protected Route: Requires JWT authentication

---

### UC-005: Update Account Details

**Primary Actor**: Registered Customer
**Goal**: Modify personal information
**Preconditions**: User is logged in and viewing profile
**Postconditions**: User information updated in database

**Main Success Scenario**:
1. User navigates to Account Details tab
2. User views current first name, last name, phone
3. User modifies desired fields
4. User clicks "Update" button
5. System validates input data
6. System updates user record in MongoDB
7. System displays success message

**Alternative Flows**:
- 5a. Invalid phone format → Display validation error

---

### UC-006: Change Password

**Primary Actor**: Registered Customer
**Goal**: Update account password
**Preconditions**: User is logged in
**Postconditions**: Password updated with new hash

**Main Success Scenario**:
1. User navigates to Password Management tab
2. User enters current password
3. User enters new password
4. User confirms new password
5. System validates current password
6. System validates new password strength
7. System hashes new password with bcrypt
8. System updates user record
9. System displays success message

**Alternative Flows**:
- 5a. Current password incorrect → Display error
- 6a. New password too weak → Display validation requirements
- 4a. Passwords don't match → Display error

---

### UC-007: Browse Homepage

**Primary Actor**: Guest User / Registered Customer
**Goal**: View landing page and featured content
**Preconditions**: None
**Postconditions**: Homepage displayed

**Main Success Scenario**:
1. User navigates to root URL (/)
2. System displays hero section with video background
3. System displays product categories (Strength, Cardio, Functional)
4. System displays featured products with images and prices
5. System displays customer testimonials
6. System displays trusted brand partners
7. User can scroll through content with smooth animations

**Alternative Flows**: None

---

### UC-008: Browse Product Categories

**Primary Actor**: Guest User / Registered Customer
**Goal**: Filter and view products by category
**Preconditions**: None
**Postconditions**: Category-filtered products displayed

**Main Success Scenario**:
1. User views product categories on homepage
2. User selects category (Strength Training, Cardio, or Functional Training)
3. System filters products by selected category
4. System displays relevant products (e.g., dumbbells, benches for Strength)
5. User can view product images and prices

**Alternative Flows**: None

---

### UC-010: Add to Cart

**Primary Actor**: Registered Customer
**Goal**: Add product to shopping cart
**Preconditions**: User is logged in
**Postconditions**: Product added to cart

**Main Success Scenario**:
1. User browses products
2. User selects desired product
3. User clicks "Add to Cart" button
4. System validates user authentication
5. System adds product to cart
6. System updates cart count in header
7. System displays confirmation message

**Alternative Flows**:
- 4a. User not logged in → Redirect to login page

---

### UC-013: Browse Blog Articles

**Primary Actor**: Guest User / Registered Customer
**Goal**: View fitness blog content
**Preconditions**: None
**Postconditions**: Blog articles displayed with pagination

**Main Success Scenario**:
1. User navigates to /blog
2. System displays 12 articles per page
3. System shows blog cards with:
   - Dynamic images from Unsplash
   - Category badge
   - Title and excerpt
   - Author and read time
4. User can hover over cards for "Read More" overlay
5. User can navigate between pages using pagination (3 pages total)

**Alternative Flows**: None

---

### UC-014: Filter Blog by Category

**Primary Actor**: Guest User / Registered Customer
**Goal**: Browse articles by fitness topic
**Preconditions**: User is on blog page
**Postconditions**: Filtered articles displayed

**Main Success Scenario**:
1. User views blog article list
2. User clicks category badge or filter
3. System filters articles by selected category (e.g., Cardio, HIIT, Yoga)
4. System displays matching articles
5. User can clear filter to view all articles

**Alternative Flows**: None

**Available Categories**:
- Cardio, Strength Training, HIIT, Yoga, Recovery, Nutrition, Weight Loss, Muscle Building, Flexibility, Running, Cycling, Swimming, Functional Training, CrossFit, Powerlifting, Bodybuilding, Calisthenics, Sports Training, Marathon Training, Core Training, Mental Health

---

### UC-017: View Order History

**Primary Actor**: Registered Customer
**Goal**: Review past orders
**Preconditions**: User is logged in
**Postconditions**: Order history displayed

**Main Success Scenario**:
1. User navigates to profile page
2. User selects "Order History" tab
3. System retrieves orders from database
4. System displays order list with:
   - Order ID
   - Order date
   - Status (Processing, Shipped, Delivered)
   - Total amount
   - Items ordered
5. User can click order for detailed view

**Alternative Flows**:
- 3a. No orders found → Display "No orders yet" message

---

### UC-019: Manage Shipping Addresses

**Primary Actor**: Registered Customer
**Goal**: Add, edit, or delete shipping addresses
**Preconditions**: User is logged in
**Postconditions**: Address book updated

**Main Success Scenario**:
1. User navigates to profile page
2. User selects "Shipping Address" tab
3. User views saved addresses
4. User can:
   - Add new address (street, city, state, zip, country)
   - Edit existing address
   - Delete address
   - Set default address
5. System validates address fields
6. System saves changes to database

**Alternative Flows**:
- 5a. Invalid zip code → Display validation error
- 3a. No addresses → Display "Add your first address" prompt

---

### UC-020: Manage Wishlist

**Primary Actor**: Registered Customer
**Goal**: Save and manage favorite products
**Preconditions**: User is logged in
**Postconditions**: Wishlist updated

**Main Success Scenario**:
1. User browses products
2. User clicks "Add to Favorites" on product
3. System adds product to user's wishlist
4. User navigates to profile → Wishlist tab
5. User views saved products with images and prices
6. User can remove items from wishlist
7. User can add items to cart from wishlist

**Alternative Flows**: None

---

## Use Case Relationships

### Include Relationships
- **UC-002 (Login)** includes **Validate JWT Token**
- **UC-001 (Register)** includes **Validate Password Strength**
- **UC-001 (Register)** includes **Hash Password**
- **UC-006 (Change Password)** includes **Hash Password**
- **UC-004 (View Profile)** includes **Validate JWT Token**
- **UC-010 (Add to Cart)** includes **Validate JWT Token**
- **UC-012 (Checkout)** includes **Validate JWT Token**

### Extend Relationships
- **UC-008 (Browse Product Categories)** extends **UC-007 (Browse Homepage)**
- **UC-014 (Filter Blog by Category)** extends **UC-013 (Browse Blog Articles)**
- **UC-018 (Track Order Status)** extends **UC-017 (View Order History)**

### Generalization
- **Registered Customer** generalizes from **Guest User** (inherits all Guest capabilities)

---

## Visual Representation

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         FIT-SETUP SYSTEM                                │
└─────────────────────────────────────────────────────────────────────────┘

ACTORS                          USE CASES

┌──────────────┐               ┌─────────────────────────────────────────┐
│  Guest User  │               │                                         │
└──────────────┘               │  AUTHENTICATION & USER MANAGEMENT       │
       │                       │  ○ UC-001: Register Account             │
       │                       │  ○ UC-002: Login to Account             │
       │───────────────────────┼──○ UC-003: Logout from Account          │
       │                       │  ○ UC-004: View Profile                 │
       │                       │  ○ UC-005: Update Account Details       │
       │                       │  ○ UC-006: Change Password              │
       │                       │                                         │
       │                       ├─────────────────────────────────────────┤
       │                       │                                         │
       │                       │  PRODUCT BROWSING & SHOPPING            │
       │───────────────────────┼──○ UC-007: Browse Homepage              │
       │───────────────────────┼──○ UC-008: Browse Product Categories    │
       │───────────────────────┼──○ UC-009: View Product Details         │
       │                       │  ○ UC-010: Add to Cart                  │
       │                       │  ○ UC-011: View Shopping Cart           │
       │                       │  ○ UC-012: Checkout                     │
       │                       │                                         │
┌──────────────┐               ├─────────────────────────────────────────┤
│ Registered   │               │                                         │
│  Customer    │               │  CONTENT & BLOG                         │
│ (inherits    │               │  ○ UC-013: Browse Blog Articles         │
│  from Guest) │───────────────┼──○ UC-014: Filter Blog by Category     │
└──────────────┘───────────────┼──○ UC-015: Read Blog Article           │
       │                       │  ○ UC-016: View Testimonials            │
       │                       │                                         │
       │                       ├─────────────────────────────────────────┤
       │                       │                                         │
       │                       │  ORDER & ACCOUNT MANAGEMENT             │
       │───────────────────────┼──○ UC-017: View Order History           │
       │───────────────────────┼──○ UC-018: Track Order Status           │
       │───────────────────────┼──○ UC-019: Manage Shipping Addresses    │
       │───────────────────────┼──○ UC-020: Manage Wishlist              │
       │───────────────────────┼──○ UC-021: Manage Workout Plans         │
       │                       │                                         │
       │                       └─────────────────────────────────────────┘
       │
       │                       ┌──────────────────┐
       │                       │  Backend API     │
       └───────────────────────│     Server       │
                               └──────────────────┘
                                       │
                                       │
                               ┌──────────────────┐
                               │    MongoDB       │
                               │    Database      │
                               └──────────────────┘
```

---

## PlantUML Diagram Code

For generating a professional UML diagram, use this PlantUML code:

```plantuml
@startuml Fit-setup Use Case Diagram

left to right direction
skinparam packageStyle rectangle

actor "Guest User" as Guest
actor "Registered Customer" as Customer
actor "Backend API" as API
actor "MongoDB Database" as DB

rectangle "Fit-setup System" {

  package "Authentication & User Management" {
    usecase "UC-001\nRegister Account" as UC001
    usecase "UC-002\nLogin to Account" as UC002
    usecase "UC-003\nLogout from Account" as UC003
    usecase "UC-004\nView Profile" as UC004
    usecase "UC-005\nUpdate Account Details" as UC005
    usecase "UC-006\nChange Password" as UC006
  }

  package "Product Browsing & Shopping" {
    usecase "UC-007\nBrowse Homepage" as UC007
    usecase "UC-008\nBrowse Product Categories" as UC008
    usecase "UC-009\nView Product Details" as UC009
    usecase "UC-010\nAdd to Cart" as UC010
    usecase "UC-011\nView Shopping Cart" as UC011
    usecase "UC-012\nCheckout" as UC012
  }

  package "Content & Blog" {
    usecase "UC-013\nBrowse Blog Articles" as UC013
    usecase "UC-014\nFilter Blog by Category" as UC014
    usecase "UC-015\nRead Blog Article" as UC015
    usecase "UC-016\nView Testimonials" as UC016
  }

  package "Order & Account Management" {
    usecase "UC-017\nView Order History" as UC017
    usecase "UC-018\nTrack Order Status" as UC018
    usecase "UC-019\nManage Shipping Addresses" as UC019
    usecase "UC-020\nManage Wishlist" as UC020
    usecase "UC-021\nManage Workout Plans" as UC021
  }

  ' Helper use cases
  usecase "Validate JWT Token" as ValidateJWT <<include>>
  usecase "Hash Password" as HashPwd <<include>>
  usecase "Validate Password Strength" as ValidatePwd <<include>>
}

' Guest User connections
Guest --> UC001
Guest --> UC002
Guest --> UC007
Guest --> UC008
Guest --> UC009
Guest --> UC013
Guest --> UC014
Guest --> UC015
Guest --> UC016

' Customer inherits from Guest
Customer --|> Guest

' Registered Customer connections
Customer --> UC003
Customer --> UC004
Customer --> UC005
Customer --> UC006
Customer --> UC010
Customer --> UC011
Customer --> UC012
Customer --> UC017
Customer --> UC018
Customer --> UC019
Customer --> UC020
Customer --> UC021

' Include relationships
UC001 ..> HashPwd : <<include>>
UC001 ..> ValidatePwd : <<include>>
UC002 ..> ValidateJWT : <<include>>
UC004 ..> ValidateJWT : <<include>>
UC006 ..> HashPwd : <<include>>
UC010 ..> ValidateJWT : <<include>>
UC012 ..> ValidateJWT : <<include>>

' Extend relationships
UC008 ..> UC007 : <<extend>>
UC014 ..> UC013 : <<extend>>
UC018 ..> UC017 : <<extend>>

' Backend interactions
API -- ValidateJWT
API -- HashPwd
API -- DB

@enduml
```

---

## Implementation Status

| Use Case | Status | Notes |
|----------|--------|-------|
| UC-001: Register Account | ✅ Implemented | Full validation with JWT |
| UC-002: Login to Account | ✅ Implemented | JWT-based authentication |
| UC-003: Logout from Account | ✅ Implemented | Client-side token removal |
| UC-004: View Profile | ✅ Implemented | Protected route with tabs |
| UC-005: Update Account Details | 🔶 Partial | UI ready, API pending |
| UC-006: Change Password | 🔶 Partial | UI ready, API pending |
| UC-007: Browse Homepage | ✅ Implemented | Full hero and product showcase |
| UC-008: Browse Product Categories | 🔶 Partial | Categories shown, filtering basic |
| UC-009: View Product Details | ❌ Not Implemented | Planned feature |
| UC-010: Add to Cart | ❌ Not Implemented | Cart page exists as stub |
| UC-011: View Shopping Cart | 🔶 Partial | Page exists, functionality pending |
| UC-012: Checkout | ❌ Not Implemented | Planned feature |
| UC-013: Browse Blog Articles | ✅ Implemented | 30 articles with pagination |
| UC-014: Filter Blog by Category | 🔶 Partial | Categories displayed, filtering basic |
| UC-015: Read Blog Article | ❌ Not Implemented | Planned feature |
| UC-016: View Testimonials | ✅ Implemented | Static testimonials on homepage |
| UC-017: View Order History | 🔶 Partial | Mock data in UI |
| UC-018: Track Order Status | 🔶 Partial | Mock data in UI |
| UC-019: Manage Shipping Addresses | 🔶 Partial | UI ready, API pending |
| UC-020: Manage Wishlist | 🔶 Partial | Mock data in UI |
| UC-021: Manage Workout Plans | 🔶 Partial | Mock data in UI |

**Legend**:
- ✅ Fully Implemented
- 🔶 Partially Implemented (UI or Backend only)
- ❌ Not Yet Implemented

---

## Priority Recommendations

### High Priority (Core E-commerce)
1. UC-010: Add to Cart - Essential for shopping functionality
2. UC-012: Checkout - Required for order processing
3. UC-009: View Product Details - Improve product information display
4. UC-005: Update Account Details - Complete user management API

### Medium Priority (Enhanced Features)
1. UC-015: Read Blog Article - Full blog article pages
2. UC-017: View Order History - Connect to real order data
3. UC-019: Manage Shipping Addresses - Full CRUD operations
4. UC-020: Manage Wishlist - Complete wishlist functionality

### Low Priority (Nice to Have)
1. UC-021: Manage Workout Plans - Additional customer engagement
2. UC-014: Filter Blog by Category - Enhanced content discovery
3. UC-018: Track Order Status - Real-time tracking integration

---

## Security Considerations

### Protected Use Cases
All use cases requiring authentication use JWT token validation:
- UC-003 through UC-006 (User Management)
- UC-010 through UC-012 (Shopping)
- UC-017 through UC-021 (Account Management)

### Password Security
- Bcrypt hashing with salt factor 10
- Minimum 8 character requirement
- Complexity validation (uppercase, lowercase, numbers, special chars)
- Real-time strength indicator

### Token Management
- JWT tokens expire after 30 days
- Tokens stored in localStorage (consider httpOnly cookies for production)
- Authorization header format: `Bearer <token>`
- Middleware validates token on protected routes

---

## API Endpoints Summary

| Endpoint | Method | Use Case | Auth Required |
|----------|--------|----------|---------------|
| `/api/auth/register` | POST | UC-001 | No |
| `/api/auth/login` | POST | UC-002 | No |
| `/api/users/profile` | GET | UC-004 | Yes |
| `/api/users/profile` | PUT | UC-005, UC-006 | Yes |
| `/api/products` | GET | UC-007, UC-008 | No |
| `/api/products/:id` | GET | UC-009 | No |
| `/api/cart` | POST | UC-010 | Yes |
| `/api/cart` | GET | UC-011 | Yes |
| `/api/orders` | POST | UC-012 | Yes |
| `/api/orders` | GET | UC-017 | Yes |
| `/api/wishlist` | GET/POST/DELETE | UC-020 | Yes |
| `/api/addresses` | GET/POST/PUT/DELETE | UC-019 | Yes |

---

## Conclusion

This use case diagram document provides a comprehensive view of the Fit-setup platform's functionality. The system is well-architected with strong authentication foundations and is ready for expansion of core e-commerce features. The next development phase should focus on completing shopping cart, checkout, and order processing functionality to enable full e-commerce operations.

For questions or clarifications about any use case, please refer to the implementation files:
- Authentication: `Backend/routes/auth.js`
- User Profile: `Frontend/src/components/UserProfile.jsx`
- Blog: `Frontend/src/components/BlogPage.jsx`
- Homepage: `Frontend/src/pages/HomePage.jsx`
