# Admin System Setup Guide

## Overview

This document explains the complete admin system implementation for the Fitsetup gym e-commerce website. The system includes role-based access control (RBAC) with two user roles: **customer** and **admin**.

---

## What Was Implemented

### 1. Backend Changes

#### **User Model Updates** (`Backend/models/User.js`)
Added the following fields to the User schema:
- `role` - Either 'customer' or 'admin' (default: 'customer')
- `firstName` - User's first name
- `lastName` - User's last name
- `phone` - Contact number
- `address` - Shipping/billing address
- Timestamps for `createdAt` and `updatedAt`

#### **Product Model** (`Backend/models/Product.js`)
Created a complete product model with:
- `name` - Product name
- `description` - Product details
- `price` - Base price
- `discount` - Percentage discount (0-100%)
- `finalPrice` - Auto-calculated after discount
- `category` - One of: Strength, Cardio, Functional, Accessories, Other
- `stock` - Available quantity
- `image` - Image URL
- `featured` - Boolean flag for featured products

#### **Admin Middleware** (`Backend/middleware/auth.js`)
Created `admin` middleware that:
- Checks if the authenticated user has `role === 'admin'`
- Returns 403 Forbidden if not an admin
- Works in combination with the existing `protect` middleware

#### **Admin Routes** (`Backend/routes/adminRoutes.js`)
All routes are protected by BOTH `protect` and `admin` middleware:

**Product Management:**
- `GET /api/admin/products` - Get all products
- `POST /api/admin/products` - Create new product
- `PUT /api/admin/products/:id` - Update product (including discount)
- `DELETE /api/admin/products/:id` - Delete product

**User Management:**
- `GET /api/admin/users` - Get all users
- `DELETE /api/admin/users/:id` - Delete user (cannot delete self)
- `PUT /api/admin/users/:id/role` - Change user role (cannot change own role)

**Statistics:**
- `GET /api/admin/stats` - Dashboard statistics (user counts, product counts, low stock alerts)

#### **Public Product Routes** (`Backend/routes/productRoutes.js`)
Public routes for customers:
- `GET /api/products` - Get all products in stock
- `GET /api/products/featured` - Get featured products
- `GET /api/products/category/:category` - Get products by category
- `GET /api/products/:id` - Get single product

#### **Authentication Updates** (`Backend/routes/auth.js`)
Updated login and register responses to include `role` field.

---

### 2. Frontend Changes

#### **Admin Dashboard Component** (`Frontend/src/components/AdminDashboard.jsx`)
Complete admin interface with three tabs:

**Statistics Tab:**
- Total users, products, admins, customers
- Low stock product alerts

**Products Tab:**
- Create new products
- Edit existing products
- Update discounts
- Delete products
- View all products in a table
- Mark products as featured

**Users Tab:**
- View all users
- Delete users (except self)
- Promote users to admin or demote to customer
- Cannot modify own role or delete self

#### **Routing Updates** (`Frontend/src/App.jsx`)
- Added `/admin` route protected by role check
- Updated user state to include `role` field
- Store role in localStorage
- Auto-redirect admins to dashboard on login

#### **Layout Updates** (`Frontend/src/components/Layout.jsx`)
- Added "Admin Dashboard" link in user dropdown (only visible to admins)
- Updated logout to clear role from localStorage

#### **Login Updates** (`Frontend/src/components/LoginPage.jsx`)
- Store role in localStorage on login/register
- Auto-redirect admins to `/admin` and customers to `/`

---

## How to Set Up

### Step 1: Start the Backend

```bash
cd Backend
npm install
npm start
```

The backend will run on `http://localhost:5000`

### Step 2: Create the First Admin User

Run the seed script to create an admin account:

```bash
cd Backend
node seedAdmin.js
```

**Default Admin Credentials:**
- Email: `admin@fitsetup.com`
- Password: `Admin@123`

**IMPORTANT:** Change this password after first login!

### Step 3: Start the Frontend

```bash
cd Frontend
npm install
npm run dev
```

The frontend will run on `http://localhost:5173` (or the port Vite assigns)

### Step 4: Test the Admin System

1. Go to `http://localhost:5173/login`
2. Login with admin credentials
3. You'll be redirected to `/admin`
4. Test creating products, managing users, etc.

---

## User Roles Explained

### Customer (Default)
- Can browse products
- Can add to cart
- Can view their own profile
- Cannot access admin dashboard
- All new registrations default to customer

### Admin
- Full access to admin dashboard
- Can create, edit, delete products
- Can add discounts to products
- Can view all users
- Can delete users (except themselves)
- Can promote/demote users
- Can view dashboard statistics
- Special "Admin Dashboard" link in navigation

---

## Security Features

1. **JWT Authentication** - All routes require valid token
2. **Role-Based Access** - Admin routes check for admin role
3. **Self-Protection** - Admins cannot delete or demote themselves
4. **Password Hashing** - bcrypt with 10 salt rounds
5. **Frontend Guards** - Routes redirect non-admins to home
6. **Middleware Chaining** - `protect` + `admin` for maximum security

---

## API Endpoints Summary

### Public Endpoints
```
POST   /api/auth/register        - Register new user
POST   /api/auth/login           - Login user
GET    /api/products             - Get all products
GET    /api/products/featured    - Get featured products
GET    /api/products/:id         - Get single product
```

### Protected Endpoints (Authenticated Users)
```
GET    /api/users/profile        - Get own profile
```

### Admin-Only Endpoints (Requires Admin Role)
```
GET    /api/admin/stats          - Dashboard statistics
GET    /api/admin/products       - Get all products (admin view)
POST   /api/admin/products       - Create product
PUT    /api/admin/products/:id   - Update product
DELETE /api/admin/products/:id   - Delete product
GET    /api/admin/users          - Get all users
DELETE /api/admin/users/:id      - Delete user
PUT    /api/admin/users/:id/role - Change user role
```

---

## How to Create More Admins

### Method 1: Using the Admin Dashboard (Recommended)
1. Login as an existing admin
2. Go to Admin Dashboard > Users tab
3. Find the user you want to promote
4. Click "Promote" button
5. User will now have admin access

### Method 2: Using the Seed Script
Edit `Backend/seedAdmin.js` with new credentials and run:
```bash
node seedAdmin.js
```

### Method 3: Manual Database Update
Connect to MongoDB and update the user document:
```javascript
db.users.updateOne(
  { email: "user@example.com" },
  { $set: { role: "admin" } }
)
```

---

## Testing the System

### Test as Customer:
1. Register a new account (default role: customer)
2. Login - should redirect to home page
3. Try accessing `/admin` - should redirect to home
4. User dropdown should NOT show "Admin Dashboard" link

### Test as Admin:
1. Login with admin credentials
2. Should redirect to `/admin` dashboard
3. Test creating a product
4. Test adding discount to product
5. Test deleting a product
6. Test viewing all users
7. Test promoting a user to admin
8. Test deleting a user
9. Verify you cannot delete yourself
10. User dropdown should show "Admin Dashboard" link

---

## Product Management Features

Admins can:
- Create products with name, description, price, category, stock, image
- Set discounts (0-100%)
- Final price is auto-calculated
- Mark products as featured
- Edit any product field
- Delete products
- View low stock alerts (< 10 items)

---

## User Management Features

Admins can:
- View all registered users
- See user roles, registration dates
- Delete any user except themselves
- Promote customers to admin
- Demote admins to customer
- Cannot modify their own role
- View total user statistics

---

## Troubleshooting

### Admin routes return 401 Unauthorized
- Check that you're logged in
- Verify token is in localStorage
- Check Authorization header is sent

### Admin routes return 403 Forbidden
- User role is not 'admin'
- Check localStorage for 'userRole'
- Verify user document in MongoDB has `role: 'admin'`

### Cannot access /admin route
- Clear localStorage and login again
- Run seed script to ensure admin exists
- Check browser console for errors

### Products not showing on frontend
- Check that products have `stock > 0`
- Public routes only show in-stock items
- Use admin dashboard to view all products

---

## File Structure

```
Backend/
├── models/
│   ├── User.js              (Updated with role field)
│   └── Product.js           (New)
├── routes/
│   ├── auth.js              (Updated to return role)
│   ├── adminRoutes.js       (New)
│   └── productRoutes.js     (New)
├── middleware/
│   └── auth.js              (Added admin middleware)
├── seedAdmin.js             (New)
└── server.js                (Updated with new routes)

Frontend/
├── src/
│   ├── components/
│   │   ├── AdminDashboard.jsx    (New)
│   │   ├── AdminDashboard.css    (New)
│   │   ├── LoginPage.jsx         (Updated to store role)
│   │   └── Layout.jsx            (Updated with admin link)
│   └── App.jsx                   (Updated with admin route)
```

---

## Next Steps (Optional Enhancements)

1. **Order Management** - Create Order model and admin routes
2. **Image Upload** - Integrate with cloud storage (AWS S3, Cloudinary)
3. **Analytics** - Add sales charts, revenue tracking
4. **Email Notifications** - Notify users of order status
5. **Product Search** - Add search and filter functionality
6. **Pagination** - For large product/user lists
7. **Audit Logs** - Track admin actions
8. **Multi-Image Support** - Multiple product images
9. **Inventory Alerts** - Email when stock is low
10. **Customer Reviews** - Product rating system

---

## Support

If you encounter any issues:
1. Check browser console for frontend errors
2. Check terminal for backend errors
3. Verify MongoDB connection
4. Ensure all dependencies are installed
5. Check that environment variables are set

---

## Security Best Practices

1. **Change default admin password immediately**
2. Use strong passwords (min 8 chars, uppercase, lowercase, numbers, special chars)
3. Never commit `.env` file to version control
4. Regularly review user roles
5. Monitor admin activity
6. Keep dependencies updated
7. Use HTTPS in production
8. Set secure JWT expiration times

---

## Conclusion

Your Fitsetup gym e-commerce website now has a complete admin system! Admins can manage products, set discounts, manage users, and view statistics. The system is secure, scalable, and ready for production use.

Happy coding!
