// src/components/CartPage.jsx
import React from 'react';

export default function CartPage() {
    return <div>Your cart is empty.</div>;
}
